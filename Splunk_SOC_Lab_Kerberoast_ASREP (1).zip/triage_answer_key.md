# SME Answer Key: Kerberoasting

- **What:** Multiple TGS requests with RC4 encryption from 192.168.1.5, .7, .9
- **Where:** Security logs, EventCode 4769
- **Who:** user1, user2, user3
- **When:** Aug 15, 2025 between 12:00–12:03
- **Why:** Attackers likely requesting tickets to extract hashes for cracking
- **How:** Tools like Rubeus in 'kerberoast' mode
