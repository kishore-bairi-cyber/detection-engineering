# Day 1 - Kerberoasting + AS-REP Roasting Detection Lab

## Included:
- 📁 Sample Logs (`kerberoast_asrep_sample.csv`)
- 🔍 Detection Logic (`savedsearches.conf`)
- 📊 Dashboard XML (`dashboard.xml`)
- 🧪 Triage Template + SME Answer Key
- 🛡️ Defensive Countermeasure Dose

---

## 🎯 Defensive Countermeasure Dose
- Enforce AES encryption; disable RC4 for service accounts
- Use Managed Service Accounts (MSAs) where possible
- Monitor for unusual spikes in Event ID 4769
- Rotate service account passwords regularly
- Audit SPNs using `SetSPN -Q */*` to limit exposure

## Setup Instructions
1. Upload `kerberoast_asrep_sample.csv` to your Splunk test instance
2. Configure `savedsearches.conf` and import `dashboard.xml`
3. Run the detection and complete the `triage_template.md`
