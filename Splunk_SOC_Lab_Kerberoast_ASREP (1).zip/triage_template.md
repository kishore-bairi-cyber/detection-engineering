# Triage Report Template: Kerberoasting / AS-REP Roasting

## What
TGS requests using RC4 encryption indicate potential Kerberoasting activity.

## Where
Windows Security Logs (Event ID 4769, 4768)

## Who
Impacted accounts: [To be filled from logs]

## When
Time range of activity: [Insert range]

## Why
Adversaries are requesting RC4-encrypted TGS tickets for offline cracking.

## How
Tools like Rubeus or Impacket are used to request service tickets using RC4.
